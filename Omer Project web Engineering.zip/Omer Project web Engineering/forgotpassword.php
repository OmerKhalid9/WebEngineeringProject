<?php
require_once "config.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];

    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();

    if ($user) {
        
        header("Location: Main.html?message=success&email=" . urlencode($email));
        exit();
    } else {
       
        header("Location: forgotpassword.html?message=error");
        exit();
    }
}

$conn->close();
?>

$conn->close();
?>