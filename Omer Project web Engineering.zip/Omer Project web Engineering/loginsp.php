<?php
require_once "config.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $password = $_POST["password"];

    try {
        $stmt = $conn->prepare("SELECT * FROM serviceProvider WHERE email = ?");
        if (!$stmt) {
            throw new Exception("Error in preparing statement: " . $conn->error);
        }

        $stmt->bind_param("s", $email);
        $stmt->execute();

        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

       
        if ($user && $password === $user["password"]) {
            header("Location: PinLoc.html");
            exit();
        } else {
            echo "Invalid email or password.";
        }

        $stmt->close();
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
    }
}

$conn->close();
?>