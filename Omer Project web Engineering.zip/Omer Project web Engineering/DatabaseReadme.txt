$host = "localhost";
$username = "omer";
$password = "omer";
$database = "omer";

 Tables:
users 
serviceProvider
 

INSERT INTO users (fname, gender, age, email, password) 

INSERT INTO serviceProvider (fname, gender, age, email, password)