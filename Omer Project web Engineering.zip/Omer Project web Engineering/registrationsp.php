<?php
require_once "config.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fname = $_POST["fname"];
    $gender = isset($_POST["gender"]) ? $_POST["gender"] : "";
    $age = $_POST["age"];
    $email = $_POST["email"];
    $password = $_POST["password"]; 

    try {
        $stmt = $conn->prepare("INSERT INTO serviceProvider (fname, gender, age, email, password) VALUES (?, ?, ?, ?, ?)");
        if (!$stmt) {
            throw new Exception("Error in preparing statement: " . $conn->error);
        }

        $stmt->bind_param("ssiss", $fname, $gender, $age, $email, $password);

        if ($stmt->execute()) {
            echo "Registration successful!";
			header("Location: Loginsp.html");
			exit();
           
        } else {
            throw new Exception("Error executing statement: " . $stmt->error);
        }
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
    } finally {
      
        if (isset($stmt)) {
            $stmt->close();
        }  
    }		
}

$conn->close();
?>